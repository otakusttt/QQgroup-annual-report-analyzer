# 安装说明

## 快速开始

### 1. 安装 Python 依赖

```bash
pip install -r requirements.txt
pip install -r backend/requirements.txt
```

### 2. 安装前端依赖

```bash
cd frontend
npm install
cd ..
```

### 3. 配置环境

复制 `config.example.py` 为 `config.py` 并根据需要修改配置：

```bash
cp config.example.py config.py
```

### 4. 启动服务

#### 方式一：使用启动脚本（Windows）

```bash
start.bat
```

#### 方式二：手动启动

**启动后端：**
```bash
cd backend
python app.py
```

**启动前端：**
```bash
cd frontend
npm run dev
```

### 5. 访问应用

打开浏览器访问：http://localhost:5173

## Docker 部署

详见 `DOCKER.md` 文件。

## 更多信息

请查看 `README.md` 获取完整文档。
